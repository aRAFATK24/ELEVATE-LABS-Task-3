// 1. Import Express (we installed it earlier)
const express = require('express');

// 2. Create an Express app
const app = express();

// 3. Middleware to parse JSON requests (explained below)
app.use(express.json());

// 4. In-memory "database" (an array of books)
let books = [
    { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald' },
    { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee' }
];

// ========== API ENDPOINTS ========== //

// 5. GET ALL BOOKS (Read)
app.get('/books', (req, res) => {
    res.status(200).json(books); // Send all books as JSON
});

// 6. GET A SPECIFIC BOOK (Read by ID)
app.get('/books/:id', (req, res) => {
    const book = books.find(b => b.id === parseInt(req.params.id));
    if (!book) return res.status(404).send('Book not found');
    res.status(200).json(book);
});

// 7. ADD A NEW BOOK (Create)
app.post('/books', (req, res) => {
    if (!req.body.title || !req.body.author) {
        return res.status(400).send('Title and author are required');
    }
    
    const book = {
        id: books.length + 1, // Auto-generate ID
        title: req.body.title,
        author: req.body.author
    };
    
    books.push(book); // Add to array
    res.status(201).json(book); // Send back the new book
});

// 8. UPDATE A BOOK (Update)
app.put('/books/:id', (req, res) => {
    const book = books.find(b => b.id === parseInt(req.params.id));
    if (!book) return res.status(404).send('Book not found');
    
    if (!req.body.title || !req.body.author) {
        return res.status(400).send('Title and author are required');
    }
    
    book.title = req.body.title; // Update title
    book.author = req.body.author; // Update author
    res.status(200).json(book); // Send updated book
});

// 9. DELETE A BOOK (Delete)
app.delete('/books/:id', (req, res) => {
    const book = books.find(b => b.id === parseInt(req.params.id));
    if (!book) return res.status(404).send('Book not found');
    
    const index = books.indexOf(book);
    books.splice(index, 1); // Remove from array
    res.status(200).json(book); // Send deleted book
});

// 10. START THE SERVER
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log('Server running on  http://localhost:3000');
});